// C++ program for the above approach
#include<iostream>
#include<string.h>
#include<string>
#define max 100
using namespace std;

// Structure of students 
struct students  
{
	string studentname;
	long int avg_cgpa;
	string branch;
	int prn_no;
	int year_of_enrollment;
};
int num;
void showMenu();

/* Array of students  to store the
data in the form of the Structure
of the Array*/

students stu[max],  tempstu[max],
	sortstu[max], sortstu1[max];

// Function to build the given datatype
void build()
{
	cout <<"\n"<<"Build The Table\n";
	cout << "Maximum Entries can be "
		<< max << "\n";

	cout << "\n"<<"Enter the number of "
	<< "Entries required :";
	cin >> num;

	if (num > 100) {
		cout << "Maximum number of "
			<< "Entries are 100 !\n";
		num = 100;
	}
	cout << "Enter the following data:\n";

	for (int i = 0; i < num; i++) {
		cout << "Student name : ";
		cin >> stu[i].studentname;

		cout << "Student Overall CGPA :";
		cin >> stu[i].avg_cgpa;

		cout << "Branch of student :";
		cin >> stu[i].branch;

		cout << "Student PRN no :";
		cin >> stu[i].prn_no;

		cout <<"Year of Enrollment :";
		cin >> stu[i].year_of_enrollment ;
	}

	showMenu();
}

// Function to insert the data into given data type
void insert()
{
	if (num < max) {
		int i = num;
		num++;

		cout << "Enter the information of the students \n";
		cout << "Student name : ";
		cin >> stu[i].studentname;

		cout << "Student avarage cpga :";
		cin >> stu[i].avg_cgpa;

		cout << "Branch of the Student :";
		cin >> stu[i].branch;

		cout <<"PRN no of Student :";
		cin >> stu[i].prn_no;

		cout <<"Enrollment Year :";
		cin >> stu[i].year_of_enrollment;
;
	}
	else {
		cout << "Students Table Full\n";
	}

	showMenu();
}

// Function to delete record at index i
void deleteIndex(int i)
{
	for (int j = i; j < num - 1; j++) 
	{
	 stu[j].studentname = stu[j + 1].studentname;
	 stu[j].avg_cgpa = stu[j + 1].avg_cgpa;
	 stu[j].branch = stu[j + 1].branch;
	 stu[j].prn_no = stu[j + 1].prn_no;
	 stu[j].year_of_enrollment = stu[j + 1].year_of_enrollment;
	}
	return;
}

// Function to delete record
void deleteRecord()
{
	cout << "Enter the students PRN no "
		<< "to Delete Record";
    int prn_no;
    cin >> prn_no;

	for (int i = 0; i < num; i++) 
	{
		if  (stu[i].prn_no == prn_no) 
		{
			deleteIndex(i);
			num--;
			break;
		}
	}
	showMenu();
}

void searchRecord()
{
	cout << "Enter the student "
		<< "PRN to Search Record :"<<endl;

	int prn_no;
	cin >> prn_no;

	for (int i = 0; i < num; i++) {

		// If the data is found
		if (stu[i].prn_no == prn_no) 
		{
			cout << "Students Name "
				<< stu[i].studentname << "\n";

			cout << " Students PRN no "
				<< stu[i].prn_no << "\n";
				
			cout << "Branch name  "
				<< stu[i].branch << "\n";

			cout <<" Overall CGPA "
				<< stu[i].avg_cgpa << "\n";

			cout <<"Year of Enrollment"
				<< stu[i].year_of_enrollment<< "\n";
			break;
		}
		else
		{
			cout<<"Sorry ! Data is not found.";
		}
	}

	showMenu();
}

// Function to show menu
void showMenu()
{

	cout << "\n\n"<<" -------------------------"
		<< "Students"<< " Placement Drive Management System"
		<< "-------------------------\n\n";

	cout << "Available Options:\n\n";
	cout << "Build Table      (1)\n";
	cout << "Insert New Entry (2)\n";
	cout << "Delete Entry	 (3)\n";
	cout << "Search a Record	 (4)\n";
	cout << "Exit	         (5)\n";

	int option;
	cin >> option;
	switch (option)
	{
	case 1:
		build();
		break;
	case 2:
		insert();
		break;
	case 3:
		deleteRecord();
		break;
	case 4:
		searchRecord();
		break;
	case 5:
		return;

	default:
		cout << "Excepted Options"
			<< " are 1/2/3/4/5";
		showMenu();
		break;
	}
	
}
int main()
{
	showMenu();
	return 0;
}
