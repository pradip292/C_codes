//to print row wise sum of pattern.....
#include<iostream>
using namespace std;
class pattern
{
	int i,j,n,sum;
	public:
	   
		void getdata()
		{
			cout<<"Enter the Number::";
			cin>>n;
		}
		void pyramid()
		{
			for(i=1;i<=n;i++)
			{ 
			    sum=0;
				for(j=1;j<=i;j++)
				{
					cout<<j;
					sum=sum+j;
				}
				cout<<"\t\t";
				cout<<"SUM::"<<sum;
				cout<<endl;
			
			}
			
		}
};
int main()
{
	pattern o;
	o.getdata();
	o.pyramid();
	return 0;
}