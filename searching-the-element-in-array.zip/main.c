
#include <stdio.h>

int main()
{
    int i,size,found;
    printf("enter the size of the array :");
    scanf("%d",&size);
    int arr[size];
    int searchelement;
    
    
    printf("enter the elements:");
    for(i=0;i<size;i++)
    {
        scanf("%d",&arr[i]);
    }
    printf("The elements in the array are :");
    for(i=0;i<size;i++)
    {
        printf(" %d", arr[i]);
    }
    printf("\nEnter the element you want to search in the array : ");
    scanf("%d",&searchelement);
    for(i=0;i<size;i++)
    {
        if(arr[i]==searchelement)
        {
        printf("element found at index %d", i);
        arr[i]==found;
        }
        else 
        {
        printf("the element is not found %d",found);
        }
    }
    

    return 0;
}

