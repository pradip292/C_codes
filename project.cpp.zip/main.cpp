#include<iostream>
#include<conio.h>
#include<string.h>
using namespace std;
/*struct admin
{
    string password ;
    int admin_id ;
};*/
struct student
{
    string name, prn_no ,branch ;
    int avg_cgpa;
};
struct company
{
    string cname, add ;
    int pkg, contact ;
};


class admin1
{
    public:
    char ch;
    int no;
    string password_id;
    string admin_name ;
};

class company1
{
    public:
    string cname, add ;
    int pkg, contact ;
    
};

class student1 : public admin1, public company1
{
	public:
	int total=0;
	student stu[100];
    company com[100];
    string name, prn_no , branch ;
    float avg_cgpa;
    int user=0;
    
    void getdata1();
    void show();
    void signup();
};

void student1 :: getdata1()
{
    cout << "How many Students data do you want to enter??" << endl;
    cin >> user;
    for (int i = total; i < total + user; i++)
    {
        cout << "Enter data of Student: " << i + 1 << endl<< endl;
        cout << "Enter Student name: ";
        cin >> stu[i].name;
        cout << "Enter Student PRN no : ";
        cin >> stu[i].prn_no;
        cout << "Enter Student Branch : ";
        cin >> stu[i].branch;
        cout << "Enter student avarage CGPA: ";
        cin >> stu[i].avg_cgpa;
        cout << "Enter Company name: ";
        cin >> com[i].cname;
        cout << "Enter company address : ";
        cin >> com[i].add;
        cout << "Enter Package of the company : ";
        cin >> com[i].pkg;
        cout << "Enter Contact Detail of the company : ";
        cin >> com[i].contact;
    }
    total = total + user;
}




void student1 :: show()
{
if (total != 0)
{
        for (int i = 0; i < total; i++)
        {
            cout << "Data of Student " << i + 1 << endl;
            cout << "Name : " << stu[i].name << endl;
            cout << "PRN no: " << stu[i].prn_no << endl;
            cout << "Branch: " << stu[i].branch << endl;
            cout << "CGPA : " << stu[i].avg_cgpa << endl;
            cout << "Company Name : " << com[i].cname << endl;
            cout << "Address :" << com[i].add<< endl;
            cout << "Package in Lakh " << com[i].pkg << endl;
            cout << "Contact :" << com[i].contact<< endl;
        }
}
else
{
    cout << "No data is entered" << endl;
}
}

int main()
{
    student1 p;
    admin1 pp;
    int no;
    cout << "\n\n\t\tPlacement Drive Management System." << endl;
    cout << "\n\n\n\t\t**Signup**" << endl;
    cout << "\t\tEnter new admin name: ";
    cin >> pp.admin_name;
    cout << "\t\tEnter new password: ";
    cin >> pp.password_id;

    cout << "\t\tYour new id is creating please wait......"<<endl;
    cout << "\n\t\tYour id created successfully !!!";

    string usrn, pswd;
    cout << "\n\n\t\tPlacement Drive Management System" << endl;
    cout << "\n\n\n\t\t   LOGIN" << endl;
    cout << "\t\tEnter admin_name: ";
    cin >> usrn;
    cout << "\t\tEnter password: ";
    cin >> pswd;
    if (usrn == pp.admin_name && pswd == pp.password_id)
    {
        char ch;
        while(no==1)
        {
            cout << "\n\nPress 1 to enter data" << endl;
            cout << "Press 2 to show data" << endl;
            cout << "Press 3 to search data" << endl;
            cout << "Press 4 to update data" << endl;
            cout << "Press 5 to delete data" << endl;
            cout << "Press 6 to logout" << endl;
            cout << "Press 7 to exit" << endl;
            cin>>ch;
            switch (ch)
            {
            case '1':
                p.getdata1();
                break;
            case '2':
                p.show();
                break;
            case '3':
                
                break;
            case '4':
                
                break;
            case '5':
                
                break;
            case '6':
                break;
            case '7':
                exit(0);
                break;
                
            default:
                cout << "\aInvalid Input" << endl;
                break;
            }
        }   
            cout<<"Do you want to continue press 1 :";
            cin>>no;
        
    }

    else if (usrn !=pp.admin_name)
    {
        cout << "\t\t\aInvalid admin_name please try again";
    }
    else if (pswd != pp.password_id)
    {
        cout << "\t\t\aInvalid password please try again";
    }
    else
    {
        cout << "\t\t\aInvalid admin_name and password";
    }
	return 0;
}