#include<iostream>
using namespace std;
class employee
{
	protected:
		char name[10];
		int age;
		char gender[10];
	public:
		void getdata1()
		{
			cout<<"enter the name of the empolyee:";
			cin>>name;
			cout<<"enter the age of the employee:";
			cin>>age;
			cout<<"enter the gender of the employee:";
			cin>>gender;
			
		}

		void display1()
	    {
	    	cout<<"name is:"<<name;
	    	cout<<"age of is:"<<age;
	    	cout<<"gender is"<<gender;
	    	
	    }
};
class company1 : public employee
{
    protected:

	char company[100];
	float salary;

	public:
		void getdata2()
		{
			cout<<"name of company:\n";
			cin>>company;
			cout<<"salary is\n";
			cin>>salary;
		}
		void display2()
		{
			cout<<"name is:"<<company;
		    cout<<"salary is"<<salary;
		}
		
};
class lan :public company1
{
	int number;
	public:
		void getdata3()
		{
			cout<<"Number of programming language known:";
			cin>>number;
			
		}
	    void display3()
	    {
	    	cout<<"Language  known are:"<<number;
		    
		}
};
int main()
{
	lan a;
	a.getdata1();
	a.getdata2();
	a.getdata3();
	a.display1();
	a.display2();
	a.display3();
    return 0;
}