# Online Python compiler (interpreter) to run Python online.
# Write Python 3 code in this online editor and run it.
def dtob(n):
    return bin(n).replace("0b", "")

list1=[]
print("Enter how many numbers you want to enter :")

a=int(input())
y=range(a)
for i in y:
    b=int(input())
    x=dtob(b) 
    list1.append(x)
print(list1)

count=[]
count=0
for j in len(list1):
    if(list1[j]==1):
        count+=1 
    else:
        count+=0 
    
    
