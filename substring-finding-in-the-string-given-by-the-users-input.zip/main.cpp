/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <string>
using namespace std;

int main()
{
    string s1,s2;
    cout<<"Enter the string :"<<endl;
    getline(cin,s1);
    cout<<"Enter the substring you want to search :"<<endl;
    getline(cin,s2);
    
    int a =s1.find(s2);
    if(a==-1)
    cout<<"THE SUBSTRING NOT FOUND";
    else
    cout<<"SUBSTRING FOUND AT INDEX :"<<a;
    return 0;
}