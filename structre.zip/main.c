
#include <stdio.h>
#include <string.h>
struct student
{
    char name[30];
    int roll;
    float CET;
    char division[1];
} stu1, stu2;
int main()
{
    printf("Enter the name of first student ");
    scanf("%s",&stu1.name);
    printf("Enter the roll of first student ");
    scanf("%d",&stu1.roll);
    printf("Enter the marks of first student in CET ");
    scanf("%f",&stu1.CET);
    printf("Enter the division of first student \n");
    scanf("%s",&stu1.division);
    printf("Enter the name of second student ");
    scanf("%s",&stu2.name);
    printf("Enter the roll of second student ");
    scanf("%d",&stu2.roll);
    printf("Enter the marks of second student in CET ");
    scanf("%f",&stu2.CET);
    printf("Enter the division of second student ");
    scanf("%s",&stu2.division);
    printf("Roll of stu2 is %d",stu2.roll);
}