/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int miles=26,yards=385;
    float kilometer;
    kilometer=1.609*(miles+yards/1760.0);
    printf("\n A marathon is %f kilometer.\n",kilometer);

    return 0;
}
