/* SWAP OF NUMBERS */

#include <stdio.h>

int main()
{
    int a, b, c;
    int *m, *n;
    m = &a;
    n = &b;
    printf("Enter the two numbers : ");
    scanf("%d%d",&a,&b);
    printf("Value of numbers before swapping : \n");
    printf("a = %d, b = %d\n", a, b);
    c = *m;
    *m = *n;
    *n = c;
    printf("Value of numbers after swapping is : \n");
    printf("a = %d, b = %d\n", *m, *n);
    
    

    return 0;
}
