
def stray(n):
    sum=0
    for i in str(n):
        sum=sum+int(i)
    return sum
n=123456
print(stray(n))

