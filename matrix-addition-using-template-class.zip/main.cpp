
#include <iostream>
#include <algorithm>
using namespace std;

template <class t1>
class matrix
{
    private:
    t1 a[3][3];
    t1 b[3][3];
    t1 c[3][3];
    
    public:
    void input()
    {
    cout<<"Enter the elements of first matrix A :"<<endl;
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
            cin>>a[i][j];
        }
    }
    cout<<"Enter the elements of first matrix B :"<<endl;
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
            cin>>b[i][j];
        }
    }
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
            c[i][j]=a[i][j]+b[i][j];
        }
    }
    }
    
    void ans(){
    cout<<"Answer is :"<<endl;
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
            cout<<c[i][j];
        }
        cout<<endl;
    }}
    
};

int main()
{
    matrix<int>obj;
    obj.input();
    obj.ans();
    return 0;
}

