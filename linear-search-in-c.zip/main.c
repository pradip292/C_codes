#include<stdio.h>
int main()
{
	int size,m,i,flag;
	printf("Enter the size of the array :");
	scanf("%d",&size);
	int a[size];
	printf("Enter the %d elements:\n",size);
	for(i=0;i<size;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("Your elements are :");
	for(i=0;i<size;i++)
	{
		printf(" %d", a[i]);	
	}
	printf("\nEnter the element you want to search :");
	scanf("%d",&m);
	for(i=0;i<size;i++)
	{
		
		if(m==a[i])
		{
			flag=1;
		    break;	
		}
		
    }
	if (flag==1)
	{
		printf("The element %d is found at index %d",m,i);
	}
    else
	{
		printf("The element not found ...");
	}
	
	
	
	return 0;
   
}