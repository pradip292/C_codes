
#include <iostream>
using namespace std;
template <class t1 , class t2>

class add
{
    private:
    t1 a;
    t2 b;
    
    public:
    
    void result(t1 m , t2 n)
    {
        a=m;
        b=n;
        cout<<a*b;
    }
    
    
};

int main()
{
    add<int,int>obj1;
    obj1.result(10,20);
    return 0;
}
