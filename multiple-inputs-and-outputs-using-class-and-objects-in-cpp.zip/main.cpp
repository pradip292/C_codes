#include <iostream>

using namespace std;
class person
{
    int age;
    char name[30];

    public:
    void get_details(void)
    {
    cout<<endl;
    cout<< "Enter your Name:"<<endl;
    cin>>name;
    cout<< "Enter your Age:"<<endl;
    cin>>age;


    }
    void display_details(void);


};
void person::display_details(void)
{
    cout<<endl;
    cout<< "NAME:"<<name<<endl;
    cout<< "AGE:"<<age<<endl;
    cout<<endl;

}

int main()
{
    int n;
    cout<<"How many records you want to insert ?"<<endl;
    cin>>n;
    person p[n];
    for(int i=0;i<n;i++)
    {
        p[i].get_details();
    }
    for(int i=0;i<n;i++)
    {
        p[i].display_details();
    }
    return 0;
}