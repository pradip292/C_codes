/******************************************************************************

            PRINTING THE ADDITION AND SUBSTRACTION OF MATRIX

*******************************************************************************/

// Online C compiler to run C program online
#include <stdio.h>
int add(int a, int b)
{
    
    int sum=a+b;
    return sum;
}
int sub(int a ,int b)
{
    
    int sub=a-b;
    return sub;
}

int main()
{
    int a,b;// Write C code here
    printf("enter the two numbers:");
    scanf("%d%d",&a,&b);
    
    printf("the addition is :%d",add(a,b));
    printf("\nthe substraction  is :%d",sub(a,b));
    
    return 0;
}