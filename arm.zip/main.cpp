#include<iostream>
using namespace std ;

class arm
{
    private:
    
    int i,size,remain;
    char number[size];
    int sum=0;
    
    public:
    
    
    void getdata()
    {
        cout<<"Enter the size of the number :";
        cin>>size;
        cout<<"Enter the number to check whether the number is armstrong or not ? :";
        cin>>number;
    }
    void display()
    {
        cout<<"Your number is :"<<number<<endl;
    }
    void check()
    {
        for(i=0;i<size;i++)
        {
           sum=number[i]*number[i]*number[i];
           sum+=sum;
        }  
        if(sum=number[size])
        {
           cout<<"The  number is armstrong ";
        }
        else
        {
           cout<<"The number is not armstong ";
        }
        

       

    }

};

int main()
{
    arm a;
    a.getdata();
    a.display();
    a.check();
    return 0;
}