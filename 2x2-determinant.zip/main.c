#include <stdio.h>

int main() 
{
    int a[2][2],i,j,d;
    printf("enter the elements");
    for(i=0;i<2;i++)
    {
        for(j=0;j<2;j++)
        {
           scanf("%d",&a[i][j]) ;
        }
    }
    d=(a[0][0]*a[1][1])-(a[0][1]*a[1][0]);
    printf("%d",d);
    return 0;
}